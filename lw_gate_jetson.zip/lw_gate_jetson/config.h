#ifndef CONFIG_H_
#define CONFIG_H_

/*
 * config.txt parser for the Jetson Nano build.
 *
 * Adds mission parameters (z1, x_target, y_target, z2) on top of the
 * existing base-gains + sweep parameters. On the Jetson, the program
 * runs unattended -- there is no console prompt for the mission.
 */

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <unordered_map>

struct AppConfig {
    // ---- Base PID gains (indices: 0=z, 1=x, 2=y, 3=phi, 4=theta, 5=psi) ----
    float kp[6] = {  5.6f,  0.23f,  0.23f, 18.0f, 18.0f, 37.0f };
    float ki[6] = {  0.5f,  0.005f, 0.005f, 0.0f,  0.0f,  0.0f };
    float kd[6] = {  5.6f,  0.31f,  0.31f,  0.9f,  0.9f,  1.8f };
    float windup[6] = { 30.0f, 1.0f, 1.0f, 10.0f, 10.0f, 10.0f };

    // ---- Sweep parameters ----
    int          active_rollouts = 1024;
    float        gain_spread     = 0.2f;
    unsigned int seed            = 0xC0FFEE;

    // ---- Mission (NEW: read from file, not prompted on Jetson) ----
    float mission_z1       = 2.0f;
    float mission_x_target = 3.0f;
    float mission_y_target = 2.0f;
    float mission_z2       = 2.0f;

    void print() const {
        std::cout << std::fixed << std::setprecision(4);
        std::cout << "  Base PID gains:\n";
        const char* labels[6] = { "z", "x", "y", "phi", "theta", "psi" };
        for (int i = 0; i < 6; ++i) {
            std::cout << "    " << labels[i]
                      << " : kp=" << kp[i]
                      << "  ki=" << ki[i]
                      << "  kd=" << kd[i]
                      << "  windup=" << windup[i] << "\n";
        }
        std::cout << "  active_rollouts = " << active_rollouts << "\n";
        std::cout << "  gain_spread     = " << gain_spread << "\n";
        std::cout << "  seed            = 0x" << std::hex << seed
                  << std::dec << "\n";
        std::cout << "  mission: z1=" << mission_z1
                  << "  target=(" << mission_x_target << ", " << mission_y_target << ")"
                  << "  z2=" << mission_z2 << "\n";
    }
};


inline std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}


inline bool apply_kv(AppConfig& cfg, const std::string& key,
                                       const std::string& value)
{
    static const std::unordered_map<std::string, int> axis_index = {
        {"z", 0}, {"x", 1}, {"y", 2},
        {"phi", 3}, {"theta", 4}, {"psi", 5}
    };

    auto to_float = [&](float& out) -> bool {
        try { out = std::stof(value); return true; }
        catch (...) { return false; }
    };
    auto to_int = [&](int& out) -> bool {
        try { out = std::stoi(value); return true; }
        catch (...) { return false; }
    };
    auto to_uint = [&](unsigned int& out) -> bool {
        try {
            if (value.size() >= 2 && value[0] == '0'
                && (value[1] == 'x' || value[1] == 'X')) {
                out = (unsigned int)std::stoul(value, nullptr, 16);
            } else {
                out = (unsigned int)std::stoul(value, nullptr, 10);
            }
            return true;
        } catch (...) { return false; }
    };

    static const char* prefixes[] = { "kp_", "ki_", "kd_", "windup_" };
    for (int p = 0; p < 4; ++p) {
        std::string pref = prefixes[p];
        if (key.rfind(pref, 0) == 0) {
            std::string ax = key.substr(pref.size());
            auto it = axis_index.find(ax);
            if (it == axis_index.end()) return false;
            float v;
            if (!to_float(v)) return false;
            switch (p) {
                case 0: cfg.kp[it->second]     = v; return true;
                case 1: cfg.ki[it->second]     = v; return true;
                case 2: cfg.kd[it->second]     = v; return true;
                case 3: cfg.windup[it->second] = v; return true;
            }
        }
    }

    // Sweep parameters
    if (key == "active_rollouts") return to_int(cfg.active_rollouts);
    if (key == "gain_spread")     return to_float(cfg.gain_spread);
    if (key == "seed")            return to_uint(cfg.seed);

    // Mission parameters (NEW)
    if (key == "mission_z1")        return to_float(cfg.mission_z1);
    if (key == "mission_x_target")  return to_float(cfg.mission_x_target);
    if (key == "mission_y_target")  return to_float(cfg.mission_y_target);
    if (key == "mission_z2")        return to_float(cfg.mission_z2);

    return false;
}


inline bool load_config(const std::string& path, AppConfig& cfg) {
    std::ifstream file(path);
    if (!file.is_open()) {
        std::cerr << "ERROR: cannot open config file: " << path << "\n";
        return false;
    }

    std::string line;
    int line_no = 0, warnings = 0;
    while (std::getline(file, line)) {
        ++line_no;
        std::string s = trim(line);
        if (s.empty() || s[0] == '#') continue;

        size_t eq = s.find('=');
        if (eq == std::string::npos) {
            std::cerr << "WARNING: line " << line_no
                      << " missing '=' : " << s << "\n";
            ++warnings;
            continue;
        }

        std::string key   = trim(s.substr(0, eq));
        std::string value = trim(s.substr(eq + 1));
        size_t hash = value.find('#');
        if (hash != std::string::npos) value = trim(value.substr(0, hash));

        if (!apply_kv(cfg, key, value)) {
            std::cerr << "WARNING: line " << line_no
                      << " unknown key or bad value: " << key
                      << " = " << value << "\n";
            ++warnings;
        }
    }

    if (warnings > 0) {
        std::cerr << "Config loaded with " << warnings << " warning(s).\n";
    }

    if (cfg.active_rollouts < 1)  cfg.active_rollouts = 1;
    if (cfg.gain_spread     < 0)  cfg.gain_spread     = 0;

    return true;
}

#endif // CONFIG_H_
